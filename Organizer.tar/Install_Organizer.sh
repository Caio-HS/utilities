sudo tar -xf Scripts.tar
sudo cp Organizer.py /usr/local/bin/Organizer.py
sudo chmod +x /usr/local/bin/Organizer.py
sudo cp run_pyScript_for_users.sh /usr/local/bin/run_pyScript_for_users.sh
sudo chmod +x /usr/local/bin/run_pyScript_for_users.sh
sudo echo "1  10  run_script_users  /usr/local/bin/run_pyScript_for_users.sh  /usr/local/bin/Organizer.py"  | sudo tee -a /etc/anacrontab
mkdir -p ~/.settings
sudo cp organizer_rules.txt ~/.settings/organizer_rules.txt
sudo rm Organizer.py run_pyScript_for_users.sh organizer_rules.txt Scripts.tar
sudo rm -- "$0"
